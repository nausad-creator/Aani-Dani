export const environment = {
	production: true,
	cookieDomain: 'http://164.52.209.69/menukard/', // -<< must be 'localhost'
	apiBaseUrl: 'http://164.52.209.69/kedar/backend/web/index.php/v1/',
	fileUrl: 'http://164.52.209.69/menukard/backend/web/uploads/menuitems/',
	fileVideoUrl: 'http://164.52.209.69/menukard/backend/web/uploads/menuitems/'
};
